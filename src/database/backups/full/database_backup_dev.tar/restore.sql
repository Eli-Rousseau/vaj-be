--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vintage_archive_jungle;
--
-- Name: vintage_archive_jungle; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vintage_archive_jungle WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE vintage_archive_jungle OWNER TO postgres;

\connect vintage_archive_jungle

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: shop; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shop;


ALTER SCHEMA shop OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: shop; Owner: postgres
--

CREATE FUNCTION shop.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION shop.set_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    article integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.favorite OWNER TO postgres;

--
-- Name: favorite_reference_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favorite_reference_seq OWNER TO postgres;

--
-- Name: favorite_reference_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorite_reference_seq OWNED BY public.favorite.reference;


--
-- Name: address; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.address (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    country character varying(255) NOT NULL,
    state_or_province character varying(255) DEFAULT NULL::character varying,
    city character varying(255) NOT NULL,
    zip_code character varying(255) NOT NULL,
    street character varying(255) NOT NULL,
    street_number character varying(255) NOT NULL,
    box character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop.address OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.address_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.address_reference_seq OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.address_reference_seq OWNED BY shop.address.reference;


--
-- Name: article; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.article (
    reference integer NOT NULL,
    title text NOT NULL,
    description text,
    brand text NOT NULL,
    release timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    parent_category text NOT NULL,
    sub_category text NOT NULL,
    gender text,
    size text NOT NULL,
    color text,
    material text,
    condition text NOT NULL,
    season text,
    quantity integer DEFAULT 1 NOT NULL,
    price double precision NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    discount double precision DEFAULT 0 NOT NULL,
    availability text NOT NULL,
    for_sale boolean NOT NULL,
    for_rent boolean NOT NULL,
    rental_price double precision,
    thumbnail jsonb,
    media jsonb,
    weight double precision NOT NULL,
    height double precision NOT NULL,
    width double precision NOT NULL,
    depth double precision NOT NULL,
    CONSTRAINT article_discount_check CHECK (((discount >= (0)::double precision) AND (discount <= (100)::double precision))),
    CONSTRAINT article_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE shop.article OWNER TO postgres;

--
-- Name: article_parent_category; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.article_parent_category (
    reference text NOT NULL
);


ALTER TABLE shop.article_parent_category OWNER TO postgres;

--
-- Name: article_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.article_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.article_reference_seq OWNER TO postgres;

--
-- Name: article_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.article_reference_seq OWNED BY shop.article.reference;


--
-- Name: article_sub_category; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.article_sub_category (
    reference text NOT NULL
);


ALTER TABLE shop.article_sub_category OWNER TO postgres;

--
-- Name: availability; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.availability (
    reference text NOT NULL
);


ALTER TABLE shop.availability OWNER TO postgres;

--
-- Name: brand; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.brand (
    reference text NOT NULL
);


ALTER TABLE shop.brand OWNER TO postgres;

--
-- Name: color; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.color (
    reference text NOT NULL
);


ALTER TABLE shop.color OWNER TO postgres;

--
-- Name: condition; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.condition (
    reference text NOT NULL
);


ALTER TABLE shop.condition OWNER TO postgres;

--
-- Name: currency; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.currency (
    reference text NOT NULL
);


ALTER TABLE shop.currency OWNER TO postgres;

--
-- Name: discount_coupon; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.discount_coupon (
    reference integer NOT NULL,
    code text NOT NULL,
    description text,
    discount_type text NOT NULL,
    discount_value double precision NOT NULL,
    max_uses integer DEFAULT 1 NOT NULL,
    uses integer DEFAULT 0 NOT NULL,
    min_order_value double precision,
    valid_from timestamp without time zone NOT NULL,
    valid_until timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    user_limit integer,
    is_stackable boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop.discount_coupon OWNER TO postgres;

--
-- Name: discount_coupon_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.discount_coupon_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.discount_coupon_reference_seq OWNER TO postgres;

--
-- Name: discount_coupon_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.discount_coupon_reference_seq OWNED BY shop.discount_coupon.reference;


--
-- Name: gender; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.gender (
    reference text NOT NULL
);


ALTER TABLE shop.gender OWNER TO postgres;

--
-- Name: material; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.material (
    reference text NOT NULL
);


ALTER TABLE shop.material OWNER TO postgres;

--
-- Name: order; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop."order" (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    total_price double precision NOT NULL,
    currency text NOT NULL,
    payment_method text NOT NULL,
    status text NOT NULL,
    type text NOT NULL,
    rental_start_date timestamp without time zone,
    rental_end_date timestamp without time zone,
    discount_coupon integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop."order" OWNER TO postgres;

--
-- Name: order_article; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.order_article (
    reference integer NOT NULL,
    "order" integer NOT NULL,
    article integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    sale_price double precision NOT NULL,
    rental_price double precision,
    discount_applied double precision DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop.order_article OWNER TO postgres;

--
-- Name: order_article_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.order_article_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.order_article_reference_seq OWNER TO postgres;

--
-- Name: order_article_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.order_article_reference_seq OWNED BY shop.order_article.reference;


--
-- Name: order_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.order_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.order_reference_seq OWNER TO postgres;

--
-- Name: order_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.order_reference_seq OWNED BY shop."order".reference;


--
-- Name: order_status; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.order_status (
    reference text NOT NULL
);


ALTER TABLE shop.order_status OWNER TO postgres;

--
-- Name: order_type; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.order_type (
    reference text NOT NULL
);


ALTER TABLE shop.order_type OWNER TO postgres;

--
-- Name: payment_method; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.payment_method (
    reference text NOT NULL
);


ALTER TABLE shop.payment_method OWNER TO postgres;

--
-- Name: season; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.season (
    reference text NOT NULL
);


ALTER TABLE shop.season OWNER TO postgres;

--
-- Name: size; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.size (
    reference text NOT NULL
);


ALTER TABLE shop.size OWNER TO postgres;

--
-- Name: system_authentication; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.system_authentication (
    reference text NOT NULL
);


ALTER TABLE shop.system_authentication OWNER TO postgres;

--
-- Name: system_permission; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.system_permission (
    reference text NOT NULL
);


ALTER TABLE shop.system_permission OWNER TO postgres;

--
-- Name: system_role; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.system_role (
    reference text NOT NULL
);


ALTER TABLE shop.system_role OWNER TO postgres;

--
-- Name: system_role_permission; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.system_role_permission (
    reference integer NOT NULL,
    system_role text NOT NULL,
    system_permission text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop.system_role_permission OWNER TO postgres;

--
-- Name: system_role_permission_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.system_role_permission_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.system_role_permission_reference_seq OWNER TO postgres;

--
-- Name: system_role_permission_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.system_role_permission_reference_seq OWNED BY shop.system_role_permission.reference;


--
-- Name: user; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop."user" (
    reference integer NOT NULL,
    name text NOT NULL,
    birthday text,
    email text NOT NULL,
    phone_number text,
    shipping_address integer,
    billing_address integer,
    password text,
    salt text,
    system_authentication text NOT NULL,
    system_role text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE shop."user" OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.user_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.user_reference_seq OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.user_reference_seq OWNED BY shop."user".reference;


--
-- Name: favorite reference; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite ALTER COLUMN reference SET DEFAULT nextval('public.favorite_reference_seq'::regclass);


--
-- Name: address reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address ALTER COLUMN reference SET DEFAULT nextval('shop.address_reference_seq'::regclass);


--
-- Name: article reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article ALTER COLUMN reference SET DEFAULT nextval('shop.article_reference_seq'::regclass);


--
-- Name: discount_coupon reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.discount_coupon ALTER COLUMN reference SET DEFAULT nextval('shop.discount_coupon_reference_seq'::regclass);


--
-- Name: order reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order" ALTER COLUMN reference SET DEFAULT nextval('shop.order_reference_seq'::regclass);


--
-- Name: order_article reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article ALTER COLUMN reference SET DEFAULT nextval('shop.order_article_reference_seq'::regclass);


--
-- Name: system_role_permission reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role_permission ALTER COLUMN reference SET DEFAULT nextval('shop.system_role_permission_reference_seq'::regclass);


--
-- Name: user reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user" ALTER COLUMN reference SET DEFAULT nextval('shop.user_reference_seq'::regclass);


--
-- Data for Name: favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite (reference, "user", article, created_at, updated_at) FROM stdin;
\.
COPY public.favorite (reference, "user", article, created_at, updated_at) FROM '$$PATH$$/3837.dat';

--
-- Data for Name: address; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.address (reference, "user", country, state_or_province, city, zip_code, street, street_number, box, created_at, updated_at) FROM stdin;
\.
COPY shop.address (reference, "user", country, state_or_province, city, zip_code, street, street_number, box, created_at, updated_at) FROM '$$PATH$$/3813.dat';

--
-- Data for Name: article; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.article (reference, title, description, brand, release, created_at, updated_at, parent_category, sub_category, gender, size, color, material, condition, season, quantity, price, currency, discount, availability, for_sale, for_rent, rental_price, thumbnail, media, weight, height, width, depth) FROM stdin;
\.
COPY shop.article (reference, title, description, brand, release, created_at, updated_at, parent_category, sub_category, gender, size, color, material, condition, season, quantity, price, currency, discount, availability, for_sale, for_rent, rental_price, thumbnail, media, weight, height, width, depth) FROM '$$PATH$$/3826.dat';

--
-- Data for Name: article_parent_category; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.article_parent_category (reference) FROM stdin;
\.
COPY shop.article_parent_category (reference) FROM '$$PATH$$/3815.dat';

--
-- Data for Name: article_sub_category; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.article_sub_category (reference) FROM stdin;
\.
COPY shop.article_sub_category (reference) FROM '$$PATH$$/3816.dat';

--
-- Data for Name: availability; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.availability (reference) FROM stdin;
\.
COPY shop.availability (reference) FROM '$$PATH$$/3824.dat';

--
-- Data for Name: brand; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.brand (reference) FROM stdin;
\.
COPY shop.brand (reference) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: color; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.color (reference) FROM stdin;
\.
COPY shop.color (reference) FROM '$$PATH$$/3819.dat';

--
-- Data for Name: condition; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.condition (reference) FROM stdin;
\.
COPY shop.condition (reference) FROM '$$PATH$$/3821.dat';

--
-- Data for Name: currency; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.currency (reference) FROM stdin;
\.
COPY shop.currency (reference) FROM '$$PATH$$/3823.dat';

--
-- Data for Name: discount_coupon; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.discount_coupon (reference, code, description, discount_type, discount_value, max_uses, uses, min_order_value, valid_from, valid_until, is_active, user_limit, is_stackable, created_at, updated_at) FROM stdin;
\.
COPY shop.discount_coupon (reference, code, description, discount_type, discount_value, max_uses, uses, min_order_value, valid_from, valid_until, is_active, user_limit, is_stackable, created_at, updated_at) FROM '$$PATH$$/3831.dat';

--
-- Data for Name: gender; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.gender (reference) FROM stdin;
\.
COPY shop.gender (reference) FROM '$$PATH$$/3817.dat';

--
-- Data for Name: material; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.material (reference) FROM stdin;
\.
COPY shop.material (reference) FROM '$$PATH$$/3820.dat';

--
-- Data for Name: order; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop."order" (reference, "user", total_price, currency, payment_method, status, type, rental_start_date, rental_end_date, discount_coupon, created_at, updated_at) FROM stdin;
\.
COPY shop."order" (reference, "user", total_price, currency, payment_method, status, type, rental_start_date, rental_end_date, discount_coupon, created_at, updated_at) FROM '$$PATH$$/3833.dat';

--
-- Data for Name: order_article; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.order_article (reference, "order", article, quantity, sale_price, rental_price, discount_applied, created_at, updated_at) FROM stdin;
\.
COPY shop.order_article (reference, "order", article, quantity, sale_price, rental_price, discount_applied, created_at, updated_at) FROM '$$PATH$$/3835.dat';

--
-- Data for Name: order_status; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.order_status (reference) FROM stdin;
\.
COPY shop.order_status (reference) FROM '$$PATH$$/3828.dat';

--
-- Data for Name: order_type; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.order_type (reference) FROM stdin;
\.
COPY shop.order_type (reference) FROM '$$PATH$$/3829.dat';

--
-- Data for Name: payment_method; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.payment_method (reference) FROM stdin;
\.
COPY shop.payment_method (reference) FROM '$$PATH$$/3827.dat';

--
-- Data for Name: season; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.season (reference) FROM stdin;
\.
COPY shop.season (reference) FROM '$$PATH$$/3822.dat';

--
-- Data for Name: size; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.size (reference) FROM stdin;
\.
COPY shop.size (reference) FROM '$$PATH$$/3818.dat';

--
-- Data for Name: system_authentication; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.system_authentication (reference) FROM stdin;
\.
COPY shop.system_authentication (reference) FROM '$$PATH$$/3808.dat';

--
-- Data for Name: system_permission; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.system_permission (reference) FROM stdin;
\.
COPY shop.system_permission (reference) FROM '$$PATH$$/3838.dat';

--
-- Data for Name: system_role; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.system_role (reference) FROM stdin;
\.
COPY shop.system_role (reference) FROM '$$PATH$$/3809.dat';

--
-- Data for Name: system_role_permission; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.system_role_permission (reference, system_role, system_permission, created_at, updated_at) FROM stdin;
\.
COPY shop.system_role_permission (reference, system_role, system_permission, created_at, updated_at) FROM '$$PATH$$/3840.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop."user" (reference, name, birthday, email, phone_number, shipping_address, billing_address, password, salt, system_authentication, system_role, created_at, updated_at) FROM stdin;
\.
COPY shop."user" (reference, name, birthday, email, phone_number, shipping_address, billing_address, password, salt, system_authentication, system_role, created_at, updated_at) FROM '$$PATH$$/3811.dat';

--
-- Name: favorite_reference_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_reference_seq', 1, false);


--
-- Name: address_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.address_reference_seq', 1, false);


--
-- Name: article_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.article_reference_seq', 1, false);


--
-- Name: discount_coupon_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.discount_coupon_reference_seq', 1, false);


--
-- Name: order_article_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.order_article_reference_seq', 1, false);


--
-- Name: order_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.order_reference_seq', 1, false);


--
-- Name: system_role_permission_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.system_role_permission_reference_seq', 1, false);


--
-- Name: user_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.user_reference_seq', 9, true);


--
-- Name: favorite favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT favorite_pkey PRIMARY KEY (reference);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (reference);


--
-- Name: article_parent_category article_parent_category_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article_parent_category
    ADD CONSTRAINT article_parent_category_pkey PRIMARY KEY (reference);


--
-- Name: article article_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT article_pkey PRIMARY KEY (reference);


--
-- Name: article_sub_category article_sub_category_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article_sub_category
    ADD CONSTRAINT article_sub_category_pkey PRIMARY KEY (reference);


--
-- Name: availability availability_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.availability
    ADD CONSTRAINT availability_pkey PRIMARY KEY (reference);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (reference);


--
-- Name: color color_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.color
    ADD CONSTRAINT color_pkey PRIMARY KEY (reference);


--
-- Name: condition condition_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.condition
    ADD CONSTRAINT condition_pkey PRIMARY KEY (reference);


--
-- Name: currency currency_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.currency
    ADD CONSTRAINT currency_pkey PRIMARY KEY (reference);


--
-- Name: discount_coupon discount_coupon_code_key; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.discount_coupon
    ADD CONSTRAINT discount_coupon_code_key UNIQUE (code);


--
-- Name: discount_coupon discount_coupon_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.discount_coupon
    ADD CONSTRAINT discount_coupon_pkey PRIMARY KEY (reference);


--
-- Name: gender gender_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.gender
    ADD CONSTRAINT gender_pkey PRIMARY KEY (reference);


--
-- Name: material material_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.material
    ADD CONSTRAINT material_pkey PRIMARY KEY (reference);


--
-- Name: order_article order_article_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT order_article_pkey PRIMARY KEY (reference);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (reference);


--
-- Name: order_status order_status_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_status
    ADD CONSTRAINT order_status_pkey PRIMARY KEY (reference);


--
-- Name: order_type order_type_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_type
    ADD CONSTRAINT order_type_pkey PRIMARY KEY (reference);


--
-- Name: payment_method payment_method_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.payment_method
    ADD CONSTRAINT payment_method_pkey PRIMARY KEY (reference);


--
-- Name: season season_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.season
    ADD CONSTRAINT season_pkey PRIMARY KEY (reference);


--
-- Name: size size_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.size
    ADD CONSTRAINT size_pkey PRIMARY KEY (reference);


--
-- Name: system_authentication system_authentication_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_authentication
    ADD CONSTRAINT system_authentication_pkey PRIMARY KEY (reference);


--
-- Name: system_permission system_permission_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_permission
    ADD CONSTRAINT system_permission_pkey PRIMARY KEY (reference);


--
-- Name: system_role_permission system_role_permission_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role_permission
    ADD CONSTRAINT system_role_permission_pkey PRIMARY KEY (reference);


--
-- Name: system_role system_role_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role
    ADD CONSTRAINT system_role_pkey PRIMARY KEY (reference);


--
-- Name: system_role_permission unique_role_system_permission; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role_permission
    ADD CONSTRAINT unique_role_system_permission UNIQUE (system_role, system_permission);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (reference);


--
-- Name: address trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.address FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: article trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.article FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: discount_coupon trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.discount_coupon FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: order trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop."order" FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: order_article trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.order_article FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: system_role_permission trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.system_role_permission FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: user trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop."user" FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: favorite fk_article; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT fk_article FOREIGN KEY (article) REFERENCES shop.article(reference) ON UPDATE CASCADE;


--
-- Name: favorite fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT fk_user FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: order_article fk_article; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT fk_article FOREIGN KEY (article) REFERENCES shop.article(reference) ON UPDATE CASCADE;


--
-- Name: article fk_article_parent_category; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_article_parent_category FOREIGN KEY (parent_category) REFERENCES shop.article_parent_category(reference) ON UPDATE CASCADE;


--
-- Name: article fk_article_sub_category; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_article_sub_category FOREIGN KEY (sub_category) REFERENCES shop.article_sub_category(reference) ON UPDATE CASCADE;


--
-- Name: article fk_availibility; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_availibility FOREIGN KEY (availability) REFERENCES shop.availability(reference) ON UPDATE CASCADE;


--
-- Name: user fk_billing_address; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT fk_billing_address FOREIGN KEY (billing_address) REFERENCES shop.address(reference) ON UPDATE CASCADE;


--
-- Name: article fk_brand; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_brand FOREIGN KEY (brand) REFERENCES shop.brand(reference) ON UPDATE CASCADE;


--
-- Name: article fk_color; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_color FOREIGN KEY (color) REFERENCES shop.color(reference) ON UPDATE CASCADE;


--
-- Name: article fk_condition; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_condition FOREIGN KEY (condition) REFERENCES shop.condition(reference) ON UPDATE CASCADE;


--
-- Name: article fk_currency; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_currency FOREIGN KEY (currency) REFERENCES shop.currency(reference) ON UPDATE CASCADE;


--
-- Name: order fk_currency; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_currency FOREIGN KEY (currency) REFERENCES shop.currency(reference) ON UPDATE CASCADE;


--
-- Name: order fk_discount_coupon; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_discount_coupon FOREIGN KEY (discount_coupon) REFERENCES shop.discount_coupon(reference) ON UPDATE CASCADE;


--
-- Name: article fk_gender; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_gender FOREIGN KEY (gender) REFERENCES shop.gender(reference) ON UPDATE CASCADE;


--
-- Name: article fk_material; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_material FOREIGN KEY (material) REFERENCES shop.material(reference) ON UPDATE CASCADE;


--
-- Name: order_article fk_order; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT fk_order FOREIGN KEY ("order") REFERENCES shop."order"(reference) ON UPDATE CASCADE;


--
-- Name: order fk_order_status; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_order_status FOREIGN KEY (status) REFERENCES shop.order_status(reference) ON UPDATE CASCADE;


--
-- Name: order fk_order_type; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_order_type FOREIGN KEY (type) REFERENCES shop.order_type(reference) ON UPDATE CASCADE;


--
-- Name: order fk_payment_method; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_payment_method FOREIGN KEY (payment_method) REFERENCES shop.payment_method(reference) ON UPDATE CASCADE;


--
-- Name: article fk_season; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_season FOREIGN KEY (season) REFERENCES shop.season(reference) ON UPDATE CASCADE;


--
-- Name: user fk_shipping_address; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT fk_shipping_address FOREIGN KEY (shipping_address) REFERENCES shop.address(reference) ON UPDATE CASCADE;


--
-- Name: article fk_size; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT fk_size FOREIGN KEY (size) REFERENCES shop.size(reference) ON UPDATE CASCADE;


--
-- Name: user fk_system_authentication; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT fk_system_authentication FOREIGN KEY (system_authentication) REFERENCES shop.system_authentication(reference) ON UPDATE CASCADE;


--
-- Name: system_role_permission fk_system_permission; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role_permission
    ADD CONSTRAINT fk_system_permission FOREIGN KEY (system_permission) REFERENCES shop.system_permission(reference) ON UPDATE CASCADE;


--
-- Name: user fk_system_role; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT fk_system_role FOREIGN KEY (system_role) REFERENCES shop.system_role(reference) ON UPDATE CASCADE;


--
-- Name: system_role_permission fk_system_role; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.system_role_permission
    ADD CONSTRAINT fk_system_role FOREIGN KEY (system_role) REFERENCES shop.system_role(reference) ON UPDATE CASCADE;


--
-- Name: address fk_user; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT fk_user FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: order fk_user; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT fk_user FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: DATABASE vintage_archive_jungle; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE vintage_archive_jungle TO administrator;


--
-- Name: SCHEMA shop; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA shop TO administrator;


--
-- Name: TABLE address; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.address TO administrator;


--
-- Name: SEQUENCE address_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.address_reference_seq TO administrator;


--
-- Name: TABLE article; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.article TO administrator;


--
-- Name: TABLE article_parent_category; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.article_parent_category TO administrator;


--
-- Name: SEQUENCE article_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.article_reference_seq TO administrator;


--
-- Name: TABLE article_sub_category; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.article_sub_category TO administrator;


--
-- Name: TABLE availability; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.availability TO administrator;


--
-- Name: TABLE brand; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.brand TO administrator;


--
-- Name: TABLE color; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.color TO administrator;


--
-- Name: TABLE condition; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.condition TO administrator;


--
-- Name: TABLE currency; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.currency TO administrator;


--
-- Name: TABLE discount_coupon; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.discount_coupon TO administrator;


--
-- Name: SEQUENCE discount_coupon_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.discount_coupon_reference_seq TO administrator;


--
-- Name: TABLE gender; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.gender TO administrator;


--
-- Name: TABLE material; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.material TO administrator;


--
-- Name: TABLE "order"; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop."order" TO administrator;


--
-- Name: TABLE order_article; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.order_article TO administrator;


--
-- Name: SEQUENCE order_article_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.order_article_reference_seq TO administrator;


--
-- Name: SEQUENCE order_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.order_reference_seq TO administrator;


--
-- Name: TABLE order_status; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.order_status TO administrator;


--
-- Name: TABLE order_type; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.order_type TO administrator;


--
-- Name: TABLE payment_method; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.payment_method TO administrator;


--
-- Name: TABLE season; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.season TO administrator;


--
-- Name: TABLE size; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.size TO administrator;


--
-- Name: TABLE system_authentication; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.system_authentication TO administrator;


--
-- Name: TABLE system_permission; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.system_permission TO administrator;


--
-- Name: TABLE system_role; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.system_role TO administrator;


--
-- Name: TABLE system_role_permission; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.system_role_permission TO administrator;


--
-- Name: SEQUENCE system_role_permission_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.system_role_permission_reference_seq TO administrator;


--
-- Name: TABLE "user"; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop."user" TO administrator;


--
-- Name: SEQUENCE user_reference_seq; Type: ACL; Schema: shop; Owner: postgres
--

GRANT ALL ON SEQUENCE shop.user_reference_seq TO administrator;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: shop; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA shop GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO administrator;


--
-- PostgreSQL database dump complete
--

