--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vintage_archive_jungle;
--
-- Name: vintage_archive_jungle; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vintage_archive_jungle WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE vintage_archive_jungle OWNER TO postgres;

\connect vintage_archive_jungle

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: shop; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shop;


ALTER SCHEMA shop OWNER TO postgres;

--
-- Name: auth_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.auth_type AS ENUM (
    'INTERN',
    'GOOGLE',
    'APPLE'
);


ALTER TYPE shop.auth_type OWNER TO postgres;

--
-- Name: role_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.role_type AS ENUM (
    'SYSTEM DEVELOPER',
    'ADMINISTRATOR',
    'SUPERUSER',
    'USER'
);


ALTER TYPE shop.role_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.address (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    country character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    zip_code character varying(255) NOT NULL,
    street character varying(255) NOT NULL,
    street_number character varying(255) NOT NULL,
    box character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop.address OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.address_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.address_reference_seq OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.address_reference_seq OWNED BY shop.address.reference;


--
-- Name: user; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop."user" (
    reference integer NOT NULL,
    name character varying(255) NOT NULL,
    birthday date,
    email character varying(255) NOT NULL,
    phone_number character varying(20) DEFAULT NULL::character varying,
    shipping_address integer,
    billing_address integer,
    password text,
    salt text,
    authentication shop.auth_type NOT NULL,
    role shop.role_type NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop."user" OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.user_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.user_reference_seq OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.user_reference_seq OWNED BY shop."user".reference;


--
-- Name: address reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address ALTER COLUMN reference SET DEFAULT nextval('shop.address_reference_seq'::regclass);


--
-- Name: user reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user" ALTER COLUMN reference SET DEFAULT nextval('shop.user_reference_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop.address (reference, "user", country, city, zip_code, street, street_number, box, created_at, updated_at) FROM stdin;
\.
COPY shop.address (reference, "user", country, city, zip_code, street, street_number, box, created_at, updated_at) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: shop; Owner: postgres
--

COPY shop."user" (reference, name, birthday, email, phone_number, shipping_address, billing_address, password, salt, authentication, role, created_at, updated_at) FROM stdin;
\.
COPY shop."user" (reference, name, birthday, email, phone_number, shipping_address, billing_address, password, salt, authentication, role, created_at, updated_at) FROM '$$PATH$$/3601.dat';

--
-- Name: address_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.address_reference_seq', 1, false);


--
-- Name: user_reference_seq; Type: SEQUENCE SET; Schema: shop; Owner: postgres
--

SELECT pg_catalog.setval('shop.user_reference_seq', 1, false);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (reference);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (reference);


--
-- Name: address address_user_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT address_user_fk FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: user user_billing_address_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_billing_address_fk FOREIGN KEY (billing_address) REFERENCES shop.address(reference) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user user_shipping_address_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_shipping_address_fk FOREIGN KEY (shipping_address) REFERENCES shop.address(reference) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DATABASE vintage_archive_jungle; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE vintage_archive_jungle TO administrator;


--
-- Name: SCHEMA shop; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA shop TO administrator;


--
-- Name: TABLE address; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.address TO administrator;


--
-- Name: TABLE "user"; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop."user" TO administrator;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: shop; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA shop GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO administrator;


--
-- PostgreSQL database dump complete
--

