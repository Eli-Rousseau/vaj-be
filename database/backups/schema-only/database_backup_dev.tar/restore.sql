--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vintage_archive_jungle;
--
-- Name: vintage_archive_jungle; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vintage_archive_jungle WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE vintage_archive_jungle OWNER TO postgres;

\connect vintage_archive_jungle

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: shop; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shop;


ALTER SCHEMA shop OWNER TO postgres;

--
-- Name: address_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.address_type AS ENUM (
    'SHIPPING',
    'BILLING'
);


ALTER TYPE shop.address_type OWNER TO postgres;

--
-- Name: auth_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.auth_type AS ENUM (
    'INTERN',
    'GOOGLE',
    'APPLE'
);


ALTER TYPE shop.auth_type OWNER TO postgres;

--
-- Name: availability; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.availability AS ENUM (
    'AVAILABLE',
    'UNAVAILABLE'
);


ALTER TYPE shop.availability OWNER TO postgres;

--
-- Name: brand; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.brand AS ENUM (
    'Unbranded',
    'Roberto Cavali',
    'Just Cavali',
    'Dolce & Gabbana',
    'Dior',
    'John Galliano',
    'Versace',
    'Blumarine',
    'Moschino',
    'Alexander McQueen',
    'Chloé',
    'Jean Paul Gaultier',
    'Betsey Johnson',
    'Channel',
    'Gucci',
    'Prada',
    'Cop Copine',
    'Emilio Pucci',
    'Escada',
    'Fendi',
    'Muxart',
    'Gaetano Navarra',
    'Gianfranco Ferre',
    'Giuseppe Zanotti',
    'Fayazi',
    'Maison Margiela',
    'Lexus'
);


ALTER TYPE shop.brand OWNER TO postgres;

--
-- Name: category; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.category AS ENUM (
    'TOPS - T-SHIRT',
    'TOPS - SHIRT',
    'TOPS - BLOUSE',
    'TOPS - TANK TOP',
    'TOPS - SWEATER',
    'TOPS - HOODIE',
    'BOTTOMS - JEANS',
    'BOTTOMS - TROUSERS',
    'BOTTOMS - SHORTS',
    'BOTTOMS - SKIRT',
    'BOTTOMS - LEGGINGS',
    'OUTERWEAR - JACKET',
    'OUTERWEAR - COAT',
    'OUTERWEAR - BLAZER',
    'OUTERWEAR - PARKA',
    'OUTERWEAR - RAINCOAT',
    'DRESSES - CASUAL',
    'DRESSES - EVENING',
    'DRESSES - GOWN',
    'DRESSES - JUMPSUIT',
    'DRESSES - ROMPER',
    'BAGS - BACKPACK',
    'BAGS - HANDBAG',
    'BAGS - CROSSBODY',
    'BAGS - TOTE',
    'BAGS - CLUTCH',
    'SHOES - SNEAKERS',
    'SHOES - BOOTS',
    'SHOES - HEELS',
    'SHOES - FLATS',
    'SHOES - SANDALS',
    'ACCESSORIES - BELT',
    'ACCESSORIES - SCARF',
    'ACCESSORIES - HAT',
    'ACCESSORIES - GLOVES',
    'ACCESSORIES - SUNGLASSES',
    'ACCESSORIES - JEWELRY',
    'UNDERGARMENTS - BRA',
    'UNDERGARMENTS - UNDERWEAR',
    'UNDERGARMENTS - SOCKS',
    'UNDERGARMENTS - THERMALS'
);


ALTER TYPE shop.category OWNER TO postgres;

--
-- Name: condition; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.condition AS ENUM (
    'NEW',
    'GREAT',
    'MODERATE',
    'POOR'
);


ALTER TYPE shop.condition OWNER TO postgres;

--
-- Name: currency; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.currency AS ENUM (
    'EUR'
);


ALTER TYPE shop.currency OWNER TO postgres;

--
-- Name: gender; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.gender AS ENUM (
    'MENSWEAR',
    'WOMENSWEAR',
    'UNISEX'
);


ALTER TYPE shop.gender OWNER TO postgres;

--
-- Name: operation_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.operation_type AS ENUM (
    'view',
    'create',
    'update',
    'delete'
);


ALTER TYPE shop.operation_type OWNER TO postgres;

--
-- Name: order_status; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.order_status AS ENUM (
    'SOLD',
    'SHIPPED',
    'COMPLETED',
    'RETURNED',
    'REFUNDED'
);


ALTER TYPE shop.order_status OWNER TO postgres;

--
-- Name: parcel_service; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.parcel_service AS ENUM (
    'bpost',
    'PostNL',
    'Mondial Relay',
    'GLS',
    'Homer',
    'DHL',
    'UPS'
);


ALTER TYPE shop.parcel_service OWNER TO postgres;

--
-- Name: payment_method; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.payment_method AS ENUM (
    'PAYPAL'
);


ALTER TYPE shop.payment_method OWNER TO postgres;

--
-- Name: role_type; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.role_type AS ENUM (
    'SYSTEM DEVELOPER',
    'ADMINISTRATOR',
    'SUPERUSER',
    'USER'
);


ALTER TYPE shop.role_type OWNER TO postgres;

--
-- Name: shipment_country; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.shipment_country AS ENUM (
    'Afghanistan',
    'Albania',
    'Algeria',
    'Andorra',
    'Angola',
    'Argentina',
    'Armenia',
    'Australia',
    'Austria',
    'Azerbaijan',
    'Bahamas',
    'Bahrain',
    'Bangladesh',
    'Belarus',
    'Belgium',
    'Belize',
    'Benin',
    'Bhutan',
    'Bolivia',
    'Bosnia and Herzegovina',
    'Botswana',
    'Brazil',
    'Brunei',
    'Bulgaria',
    'Burkina Faso',
    'Burundi',
    'Cambodia',
    'Cameroon',
    'Canada',
    'Cape Verde',
    'Central African Republic',
    'Chad',
    'Chile',
    'China',
    'Colombia',
    'Comoros',
    'Costa Rica',
    'Croatia',
    'Cuba',
    'Cyprus',
    'Czech Republic',
    'Democratic Republic of the Congo',
    'Denmark',
    'Djibouti',
    'Dominica',
    'Dominican Republic',
    'Ecuador',
    'Egypt',
    'El Salvador',
    'Equatorial Guinea',
    'Eritrea',
    'Estonia',
    'Eswatini',
    'Ethiopia',
    'Fiji',
    'Finland',
    'France',
    'Gabon',
    'Gambia',
    'Georgia',
    'Germany',
    'Ghana',
    'Greece',
    'Grenada',
    'Guatemala',
    'Guinea',
    'Guinea-Bissau',
    'Guyana',
    'Haiti',
    'Honduras',
    'Hungary',
    'Iceland',
    'India',
    'Indonesia',
    'Iran',
    'Iraq',
    'Ireland',
    'Israel',
    'Italy',
    'Ivory Coast',
    'Jamaica',
    'Japan',
    'Jordan',
    'Kazakhstan',
    'Kenya',
    'Kiribati',
    'Kuwait',
    'Kyrgyzstan',
    'Laos',
    'Latvia',
    'Lebanon',
    'Lesotho',
    'Liberia',
    'Libya',
    'Liechtenstein',
    'Lithuania',
    'Luxembourg',
    'Madagascar',
    'Malawi',
    'Malaysia',
    'Maldives',
    'Mali',
    'Malta',
    'Marshall Islands',
    'Mauritania',
    'Mauritius',
    'Mexico',
    'Micronesia',
    'Moldova',
    'Monaco',
    'Mongolia',
    'Montenegro',
    'Morocco',
    'Mozambique',
    'Myanmar',
    'Namibia',
    'Nauru',
    'Nepal',
    'Netherlands',
    'New Zealand',
    'Nicaragua',
    'Niger',
    'Nigeria',
    'North Korea',
    'North Macedonia',
    'Norway',
    'Oman',
    'Pakistan',
    'Palau',
    'Palestine',
    'Panama',
    'Papua New Guinea',
    'Paraguay',
    'Peru',
    'Philippines',
    'Poland',
    'Portugal',
    'Qatar',
    'Republic of the Congo',
    'Romania',
    'Russia',
    'Rwanda',
    'Saint Kitts and Nevis',
    'Saint Lucia',
    'Saint Vincent and the Grenadines',
    'Samoa',
    'San Marino',
    'Sao Tome and Principe',
    'Saudi Arabia',
    'Senegal',
    'Serbia',
    'Seychelles',
    'Sierra Leone',
    'Singapore',
    'Slovakia',
    'Slovenia',
    'Solomon Islands',
    'Somalia',
    'South Africa',
    'South Korea',
    'South Sudan',
    'Spain',
    'Sri Lanka',
    'Sudan',
    'Suriname',
    'Sweden',
    'Switzerland',
    'Syria',
    'Taiwan',
    'Tajikistan',
    'Tanzania',
    'Thailand',
    'Timor-Leste',
    'Togo',
    'Tonga',
    'Trinidad and Tobago',
    'Tunisia',
    'Turkey',
    'Turkmenistan',
    'Tuvalu',
    'Uganda',
    'Ukraine',
    'United Arab Emirates',
    'United Kingdom',
    'United States',
    'Uruguay',
    'Uzbekistan',
    'Vanuatu',
    'Vatican City',
    'Venezuela',
    'Vietnam',
    'Yemen',
    'Zambia',
    'Zimbabwe'
);


ALTER TYPE shop.shipment_country OWNER TO postgres;

--
-- Name: size; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop.size AS ENUM (
    'XS',
    'S',
    'M',
    'L',
    'XL'
);


ALTER TYPE shop.size OWNER TO postgres;

--
-- Name: table; Type: TYPE; Schema: shop; Owner: postgres
--

CREATE TYPE shop."table" AS ENUM (
    'address',
    'article',
    'order',
    'order_article',
    'shipment_category',
    'role_permission',
    'user'
);


ALTER TYPE shop."table" OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: shop; Owner: postgres
--

CREATE FUNCTION shop.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION shop.set_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.address (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    country character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    zip_code character varying(255) NOT NULL,
    street character varying(255) NOT NULL,
    street_number character varying(255) NOT NULL,
    box character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop.address OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.address_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.address_reference_seq OWNER TO postgres;

--
-- Name: address_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.address_reference_seq OWNED BY shop.address.reference;


--
-- Name: article; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.article (
    reference integer NOT NULL,
    title character varying(255) NOT NULL,
    brand shop.brand NOT NULL,
    quantity integer DEFAULT 1,
    category shop.category NOT NULL,
    size shop.size NOT NULL,
    condition shop.condition NOT NULL,
    gender shop.gender NOT NULL,
    description text,
    status shop.availability NOT NULL,
    price double precision,
    currency shop.currency DEFAULT 'EUR'::shop.currency,
    for_rent boolean NOT NULL,
    discount double precision DEFAULT 0,
    media jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT article_discount_check CHECK (((discount >= (0)::double precision) AND (discount <= (100)::double precision))),
    CONSTRAINT article_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE shop.article OWNER TO postgres;

--
-- Name: article_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.article_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.article_reference_seq OWNER TO postgres;

--
-- Name: article_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.article_reference_seq OWNED BY shop.article.reference;


--
-- Name: order; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop."order" (
    reference integer NOT NULL,
    "user" integer NOT NULL,
    total_price double precision NOT NULL,
    currency shop.currency NOT NULL,
    payment_method shop.payment_method NOT NULL,
    status shop.order_status NOT NULL,
    shipment_category integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop."order" OWNER TO postgres;

--
-- Name: order_article; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.order_article (
    reference integer NOT NULL,
    "order" integer NOT NULL,
    article integer NOT NULL,
    quantity integer DEFAULT 1,
    unit_price double precision NOT NULL,
    discount double precision DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT order_article_discount_check CHECK (((discount >= (0)::double precision) AND (discount <= (100)::double precision))),
    CONSTRAINT order_article_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE shop.order_article OWNER TO postgres;

--
-- Name: order_article_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.order_article_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.order_article_reference_seq OWNER TO postgres;

--
-- Name: order_article_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.order_article_reference_seq OWNED BY shop.order_article.reference;


--
-- Name: order_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.order_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.order_reference_seq OWNER TO postgres;

--
-- Name: order_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.order_reference_seq OWNED BY shop."order".reference;


--
-- Name: role_permission; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.role_permission (
    reference integer NOT NULL,
    role shop.role_type NOT NULL,
    operation_type shop.operation_type NOT NULL,
    "table" shop."table" NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop.role_permission OWNER TO postgres;

--
-- Name: role_permission_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.role_permission_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.role_permission_reference_seq OWNER TO postgres;

--
-- Name: role_permission_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.role_permission_reference_seq OWNED BY shop.role_permission.reference;


--
-- Name: shipment_category; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop.shipment_category (
    reference integer NOT NULL,
    parcel_service shop.parcel_service NOT NULL,
    min_weight_kg double precision NOT NULL,
    max_weight_kg double precision NOT NULL,
    country shop.shipment_country NOT NULL,
    cost double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop.shipment_category OWNER TO postgres;

--
-- Name: shipment_category_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.shipment_category_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.shipment_category_reference_seq OWNER TO postgres;

--
-- Name: shipment_category_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.shipment_category_reference_seq OWNED BY shop.shipment_category.reference;


--
-- Name: user; Type: TABLE; Schema: shop; Owner: postgres
--

CREATE TABLE shop."user" (
    reference integer NOT NULL,
    name character varying(255) NOT NULL,
    birthday date,
    email character varying(255) NOT NULL,
    phone_number character varying(20) DEFAULT NULL::character varying,
    shipping_address integer,
    billing_address integer,
    password text,
    salt text,
    authentication shop.auth_type NOT NULL,
    role shop.role_type NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shop."user" OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE; Schema: shop; Owner: postgres
--

CREATE SEQUENCE shop.user_reference_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE shop.user_reference_seq OWNER TO postgres;

--
-- Name: user_reference_seq; Type: SEQUENCE OWNED BY; Schema: shop; Owner: postgres
--

ALTER SEQUENCE shop.user_reference_seq OWNED BY shop."user".reference;


--
-- Name: address reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address ALTER COLUMN reference SET DEFAULT nextval('shop.address_reference_seq'::regclass);


--
-- Name: article reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article ALTER COLUMN reference SET DEFAULT nextval('shop.article_reference_seq'::regclass);


--
-- Name: order reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order" ALTER COLUMN reference SET DEFAULT nextval('shop.order_reference_seq'::regclass);


--
-- Name: order_article reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article ALTER COLUMN reference SET DEFAULT nextval('shop.order_article_reference_seq'::regclass);


--
-- Name: role_permission reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.role_permission ALTER COLUMN reference SET DEFAULT nextval('shop.role_permission_reference_seq'::regclass);


--
-- Name: shipment_category reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.shipment_category ALTER COLUMN reference SET DEFAULT nextval('shop.shipment_category_reference_seq'::regclass);


--
-- Name: user reference; Type: DEFAULT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user" ALTER COLUMN reference SET DEFAULT nextval('shop.user_reference_seq'::regclass);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (reference);


--
-- Name: article article_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.article
    ADD CONSTRAINT article_pkey PRIMARY KEY (reference);


--
-- Name: order_article order_article_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT order_article_pkey PRIMARY KEY (reference);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (reference);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (reference);


--
-- Name: shipment_category shipment_category_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.shipment_category
    ADD CONSTRAINT shipment_category_pkey PRIMARY KEY (reference);


--
-- Name: role_permission unique_role_operation_table; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.role_permission
    ADD CONSTRAINT unique_role_operation_table UNIQUE (role, operation_type, "table");


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (reference);


--
-- Name: address trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.address FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: article trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.article FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: order trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop."order" FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: order_article trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.order_article FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: role_permission trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.role_permission FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: shipment_category trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop.shipment_category FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: user trigger_set_updated_at; Type: TRIGGER; Schema: shop; Owner: postgres
--

CREATE TRIGGER trigger_set_updated_at BEFORE UPDATE ON shop."user" FOR EACH ROW EXECUTE FUNCTION shop.set_updated_at();


--
-- Name: address address_user_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.address
    ADD CONSTRAINT address_user_fk FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: order_article order_article_article_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT order_article_article_fk FOREIGN KEY (article) REFERENCES shop.article(reference) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_article order_article_order_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop.order_article
    ADD CONSTRAINT order_article_order_fk FOREIGN KEY ("order") REFERENCES shop."order"(reference) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order order_shipment_category_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT order_shipment_category_fk FOREIGN KEY (shipment_category) REFERENCES shop.shipment_category(reference) ON UPDATE CASCADE;


--
-- Name: order order_user_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."order"
    ADD CONSTRAINT order_user_fk FOREIGN KEY ("user") REFERENCES shop."user"(reference) ON UPDATE CASCADE;


--
-- Name: user user_billing_address_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_billing_address_fk FOREIGN KEY (billing_address) REFERENCES shop.address(reference) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user user_shipping_address_fk; Type: FK CONSTRAINT; Schema: shop; Owner: postgres
--

ALTER TABLE ONLY shop."user"
    ADD CONSTRAINT user_shipping_address_fk FOREIGN KEY (shipping_address) REFERENCES shop.address(reference) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DATABASE vintage_archive_jungle; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE vintage_archive_jungle TO administrator;


--
-- Name: SCHEMA shop; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA shop TO administrator;


--
-- Name: TABLE address; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.address TO administrator;


--
-- Name: TABLE article; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.article TO administrator;


--
-- Name: TABLE "order"; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop."order" TO administrator;


--
-- Name: TABLE order_article; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.order_article TO administrator;


--
-- Name: TABLE role_permission; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.role_permission TO administrator;


--
-- Name: TABLE shipment_category; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop.shipment_category TO administrator;


--
-- Name: TABLE "user"; Type: ACL; Schema: shop; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE shop."user" TO administrator;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: shop; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA shop GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO administrator;


--
-- PostgreSQL database dump complete
--

